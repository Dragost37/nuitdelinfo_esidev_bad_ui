<template>
  <div class="app chaos">
    <component
      :is="pages[currentPage]"
      :form="form"
      :photo="photo"
      :photoPreview="photoPreview"
      @updatePhoto="photo = $event"
      @updatePhotoPreview="photoPreview = $event"
      @next="nextPage"
      @prev="prevPage"
      @submit="submitForm"
    />
  </div>
  <div id="app">
  <!-- Masque noir avec halo lumineux -->
  <div
    v-if="isDark"
    class="dark-mask"
    @mousemove="handleMouseMove"
  >
    <div
      class="light-effect"
      :style="{ top: mouseY + 'px', left: mouseX + 'px' }"
    ></div>
    <img
      src="./assets/lightbulb.png"
      alt="Ampoule"
      class="hidden-image"
      :class="{ visible: isInLight }"
      ref="image"
      @click="resetPage"
    />
  </div> <!-- Fin de la div `dark-mask` -->
</div> <!-- Fin de la div `app` -->
</template>

<script>
import PhotoForm from './components/PhotoForm.vue';
import AddressForm from './components/AddresseForm.vue';
import AdditionalInfoForm from './components/AdditionalInfo.vue';
import Home from './components/Home.vue';

import "./assets/filter.css"; // Importation des styles du filtre
export default {
  data() {
    return {
      currentPage: 0,
      pages: [Home, PhotoForm, AddressForm, AdditionalInfoForm],
      form: {
        firstName: '',
        lastName: '',
        email: '',
        nationality: '',
        country: '',
        birthDate: '',
        postalCode: '',
        city: '',
        gender: '',
      },
      photo: null,
    photoPreview: null,
    isDark: true, // Active ou désactive le mode sombre
    mouseX: 0, // Position X de la souris
    mouseY: 0, // Position Y de la souris
    radius: 100, // Rayon du halo lumineux
    isInLight: false, // Vérifie si l’ampoule est dans le halo lumineux
    };
  },
  methods: {
    validatePage() {
      // Définir les champs obligatoires par page
      const requiredFields = {
        2: ['country', 'postalCode', 'city'], // Champs pour AddressForm
        3: ['nationality', 'birthDate', 'gender'], // Champs pour AdditionalInfoForm
      };

      const fields = requiredFields[this.currentPage] || [];

      // Vérifier si chaque champ obligatoire est rempli
      for (const field of fields) {
        if (!this.form[field]) {
          this.errorMessage = `Le champ "${field}" est obligatoire.`;
          this.showModal = true; // Afficher une modal avec le message d'erreur
          return false;
        }
      }

      return true; // Tous les champs sont valides
    },
    handleMouseMove(event) {
  if (!this.isDark) return;

  const rect = event.currentTarget.getBoundingClientRect();
  this.mouseX = event.clientX - rect.left - 75;
  this.mouseY = event.clientY - rect.top - 75 ;

  const img = this.$refs.image;
  if (img) {
    const imgRect = img.getBoundingClientRect();
    const centerX = imgRect.left + imgRect.width / 2 - rect.left;
    const centerY = imgRect.top + imgRect.height / 2 - rect.top;

    const dx = centerX - this.mouseX;
    const dy = centerY - this.mouseY;
    this.isInLight = Math.sqrt(dx * dx + dy * dy) < this.radius;
  }
},
resetPage() {
    this.isDark = false; // Désactive le masque sombre
    this.mouseX = 0; // Réinitialise la position X de la lumière
    this.mouseY = 0; // Réinitialise la position Y de la lumière
    this.isInLight = false; // Réinitialise l'état de l'ampoule
    alert("Ampoule cliquée !"); // Vérification visuelle
  },
  validatePage() {
  const requiredFields = {
    2: ['country', 'postalCode', 'city'], // Champs pour AddressForm
    3: ['nationality', 'birthDate', 'gender'], // Champs pour AdditionalInfoForm
  };

  const fields = requiredFields[this.currentPage] || [];

  // Vérifie les champs obligatoires pour la page actuelle
  for (const field of fields) {
    if (!this.form[field]) {
      this.errorMessage = `Le champ "${field}" est obligatoire.`;
      this.showModal = true; // Affiche une modal avec le message d'erreur
      return false; // Arrête la validation
    }
  }

  return true; // Tous les champs sont valides
},
validatePhoto() {
  if (!this.photo) {
    this.errorMessage = 'Veuillez ajouter une photo.';
    this.showModal = true;
    return false; // Stoppe la validation
  }

  const fileType = this.photo.type;
  if (fileType !== 'image/jpeg') {
    this.errorMessage = 'Le fichier doit être au format JPEG.';
    this.showModal = true;
    return false; // Stoppe la validation
  }

  return true; // La photo est valide
},
validateAndNextPage() {
  if (this.currentPage === 0) {
    // Validation de la photo
    if (!this.photo) {
      alert('Veuillez ajouter une photo avant de continuer.');
      return;
    }
    if (this.photo.type !== 'image/jpeg') {
      alert('Le fichier photo doit être au format JPEG.');
      return;
    }
  } else {
    // Validation des champs obligatoires
    const requiredFields = {
      1: ['country', 'postalCode', 'city'],
      2: ['nationality', 'birthDate', 'gender'],
    };

    const fields = requiredFields[this.currentPage] || [];

    for (const field of fields) {
      if (!this.form[field]) {
        alert(`Le champ "${field}" est obligatoire. Veuillez le remplir avant de continuer.`);
        return;
      }
    }
  }

  // Passe à la page suivante
  this.nextPage();
},
    nextPage() {
      if (this.currentPage < this.pages.length - 1) this.currentPage++;
    },
    prevPage() {
      if (this.currentPage > 0) this.currentPage--;
    },
    submitForm() {
      console.log('Formulaire soumis :', this.form);
      alert('Formulaire soumis avec succès !');
    },
  },
};
</script>