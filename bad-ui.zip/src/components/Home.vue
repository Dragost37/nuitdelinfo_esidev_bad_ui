<template>
    <div class="anti-ux-page">
      <!-- Bouton en haut à gauche -->
      <div class="fake-button" @click="blockUser">
        Accès à la page suivante
      </div>
  
      <h1>Bienvenue sur la pire interface</h1>
      <p>
        Bienvenue dans une exploration déroutante des modèles anti-design.<br />
        Pour continuer, trouvez l'élément <span class="cliquable" @click="goToNextPage">cliquable</span>
        .
      </p>
      <p class="click-instructions">
        Vous pouvez également <span class="cliquer" @click="blockUser">cliquer</span> <span class="ici" @click="blockUserWithHint">ici</span> si vous osez.
      </p>
      <button
        @mouseover="toggleButtonText"
        @mouseleave="toggleButtonText"
        @click="showAlert"
      >{{ buttonText }}</button>
  
      <!-- Signature Esi'Dev -->
      <footer class="footer">
        <p>Fait par <span class="esi-dev">Esi'Dev</span></p>
      </footer>
  
      <!-- Modale pour bloquer l'utilisateur -->
      <div v-if="isBlocked" class="blocking-modal">
        <p v-if="isHintMode">
          Ce n'était pas ça, mais vous êtes sur la bonne voie.<br />
          Réssayez dans 45 secondes (anti-spam) 😈.
        </p>
        <p v-else>
          Vous êtes bloqué ici pendant {{ blockTime }} secondes.<br />
          Réfléchissez à vos choix (anti-spam) 😈.
        </p>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: "Home",
    data() {
      return {
        isBlocked: false, // Gère l'état de blocage
        isHintMode: false, // Active le mode "indice" pour le clic sur "ici"
        blockTime: 30, // Temps de blocage standard
        hintTime: 45, // Temps de blocage pour "ici"
        buttonText: "Click", // Texte initial du bouton
      };
    },
    methods: {
      showAlert() {
        alert("Raté! Ce bouton ne fait rien.");
      },
      blockUser() {
        // Bloque avec le message standard
        this.isBlocked = true;
        this.isHintMode = false; // Pas de mode indice
        setTimeout(() => {
          this.isBlocked = false; // Débloque après 30 secondes
          alert("Vous pouvez continuer maintenant.");
        }, this.blockTime * 1000); // 30 secondes
      },
      blockUserWithHint() {
        // Bloque avec un message personnalisé pour "ici"
        this.isBlocked = true;
        this.isHintMode = true; // Active le mode indice
        setTimeout(() => {
          this.isBlocked = false; // Débloque après 45 secondes
          alert("Ce n'était pas la bonne réponse, mais continuez. Vous êtes sur la bonne voie !");
        }, this.hintTime * 1000); // 45 secondes
      },
      goToNextPage() {
    console.log('goToNextPage called'); // Pour vérifier si elle est appelée
    this.$emit('next'); // Émet l'événement vers le parent
  },
      toggleButtonText() {
        // Change le texte du bouton entre "Click" et "Here"
        this.buttonText = this.buttonText === "Click" ? "Here" : "Click";
      },
    },
  };
  </script>
  
  <style scoped>
  /* Style pour la page anti-UX */
  .anti-ux-page {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%; /* Largeur totale sans inclure la barre de défilement */
  height: 100vh; /* Hauteur totale de la fenêtre */
  overflow: hidden; /* Cache les débordements internes */
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #2a2a2a;
}

*, *::before, *::after {
  box-sizing: border-box; /* Inclut les bordures et marges dans les dimensions */
  max-width: 100%; /* Empêche les débordements horizontaux */
  max-height: 100%; /* Empêche les débordements verticaux */
}
  
  /* Faux bouton : haut à gauche */
  .fake-button {
    position: absolute;
    top: 10px;
    left: 10px;
    background: transparent;
    color: #fff;
    border: 2px solid #fff;
    padding: 10px 20px;
    cursor: pointer;
    text-align: center;
  }
  
  .fake-button:hover {
    background: #ff0000; /* Changement de couleur au survol */
    color: #000;
  }
  
  h1 {
    font-size: 3rem;
    color: #ff00ff; /* Couleur vive pour attirer l'attention */
    text-shadow: 3px 3px #000;
    transform: rotate(-2deg);
  }
  
  p {
    text-align: center;
    font-size: 1.2rem;
    line-height: 1.5;
    margin: 20px;
    color: #a6a6a6;
  }
  
  /* Style pour "cliquable" */
  .cliquable {
    color: inherit; /* Même couleur que le texte environnant */
    cursor: text; /* Curseur inchangé pour ressembler aux autres mots */
    text-decoration: none; /* Pas de soulignement */
  }
  
  /* Style pour "cliquer" */
  .cliquer {
    text-decoration: underline; /* Souligne "cliquer" */
    color: inherit;
    cursor: text; /* Indique que c'est cliquable */
  }
  
  /* Style pour "ici" */
  .ici {
    /* Souligne "ici" */
    color: inherit;
    cursor: text; /* Indique que c'est cliquable */
  }
  
  /* Style du bouton "Click/Here" */
  button {
    margin-top: 20px;
    padding: 10px 30px;
    font-size: 1.2rem;
    background-color: #4caf50;
    color: #fff;
    border: none;
    cursor: pointer;
    border-radius: 50%;
    transform: scale(1.5); /* Taille disproportionnée */
    transition: background-color 0.3s ease, transform 0.3s ease;
  }
  
  button:hover {
    transform: scale(0.9); /* Rétrécit à l'inverse des attentes */
    background-color: #f44336;
  }
  
  /* Style pour la signature "Fait par Esi'Dev" */
  .footer {
    position: absolute;
    bottom: 50px; /* Légèrement remonté */
    width: 100%;
    text-align: center;
    animation: fadeIn 1s ease-in-out infinite alternate;
  }
  
  .footer p {
    color: #ff4500;
    font-size: 1.5rem;
    font-family: 'Georgia', serif;
    font-weight: bold;
  }
  
  .esi-dev {
    color: #ffd700;
    font-weight: bold;
    font-style: italic;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
  }
  
  /* Style pour la modale de blocage */
  .blocking-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.9);
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-size: 1.5rem;
    z-index: 1000; /* Au-dessus de tout */
    text-align: center;
    animation: fadeIn 0.5s ease-in-out;
  }
  
  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
  </style>