<template>
  <div>
    <h3>Photo de profil</h3>
    <div class="form-group">
      <label for="photo">Photo :</label>
      <input type="file" id="photo" @change="onPhotoChange" required />
      <img
        v-if="photoPreview"
        :src="photoPreview"
        alt="Prévisualisation"
        style="max-width: 150px; margin-top: 10px;"
      />
    </div>
    <button
      @mousedown="startTimer"
      @mouseup="clearTimer"
      @mouseleave="clearTimer"
    >
      Suivant
    </button>
    <p v-if="holdProgress > 0">
      Maintenez le bouton pour passer à la page suivante : {{ holdProgress }}%
    </p>

    <!-- Modale chaotique -->
    <div v-if="showModal" class="chaos-modal">
      <div class="modal-content">
        <h3>Erreur !</h3>
        <p>{{ errorMessage }}</p>
        <p>Pour fermer cette fenêtre, cliquez sur "OK" {{ clicksNeeded }} fois.</p>
        <button
          @click="handleModalClick"
          :style="randomStyle"
          class="chaos-button"
        >
          OK
        </button>
      </div>
    </div>
  </div>
</template>

<script>
// import "@/assets/PhotoForm.css"; 
export default {
  props: ['form', 'photo', 'photoPreview'],
  data() {
    return {
      holdTime: 3000, // Temps requis pour maintenir le bouton (en ms)
      timer: null,
      startTime: null,
      holdProgress: 0,
      showModal: false,
      clicksNeeded: 5, // Nombre de clics nécessaires pour fermer la modale
    };
  },
  computed: {
    isPhotoUploaded() {
      return !!this.photoPreview;
    },
    randomStyle() {
      // Style aléatoire pour le bouton
      const top = Math.random() * 80 + '%';
      const left = Math.random() * 80 + '%';
      return {
        position: 'absolute',
        top,
        left,
      };
    },
  },
  methods: {
    onPhotoChange(event) {
    const file = event.target.files[0];
    if (file) {
      // Vérification du type de fichier
      if (file.type !== 'image/jpeg') {
        this.errorMessage = 'Le fichier doit être au format JPEG.';
        this.showModal = true;
        return;
        }

        this.$emit('updatePhoto', file);

        // Vérification des dimensions de l'image
        const img = new Image();
        img.src = URL.createObjectURL(file);
        img.onload = () => {
          if (img.width < 300 || img.height < 300) {
            this.errorMessage =
              'Les dimensions de l’image doivent être d’au moins 300x300 pixels.';
            this.showModal = true;
          } else {
            this.$emit('updatePhotoPreview', img.src);
          }
        };
      }
    },
    startTimer() {
      this.startTime = Date.now();
      this.timer = setInterval(() => {
        const elapsedTime = Date.now() - this.startTime;
        this.holdProgress = Math.min(
          Math.floor((elapsedTime / this.holdTime) * 100),
          100
        );
        if (elapsedTime >= this.holdTime) {
          this.clearTimer();
          if (this.isPhotoUploaded) {
            this.nextPage();
          } else {
            this.showModal = true;
          }
        }
      }, 100);
    },
    clearTimer() {
      clearInterval(this.timer);
      this.timer = null;
      this.startTime = null;
      this.holdProgress = 0;
    },
    handleModalClick() {
      this.clicksNeeded -= 1;
      if (this.clicksNeeded <= 0) {
        this.closeModal();
      }
    },
    closeModal() {
      this.showModal = false;
      this.clicksNeeded = 5; // Réinitialise les clics pour la prochaine fois
    },
    nextPage() {
      this.$emit('next');
    },
  },
  mounted() {
    // Ajoute une classe spécifique au body
    document.body.className = "photo-form-body";
  },
  beforeUnmount() {
    // Réinitialise le body lorsque le composant est démonté
    document.body.className = "";
  },
};
</script>

<style scoped>
/* Styles délibérément chaotiques */
.chaos-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(255, 0, 255, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  position: relative;
  background: white;
  padding: 20px;
  border: 5px dashed purple;
  text-align: center;
  box-shadow: 0 0 20px 5px black;
}

.chaos-button {
  font-size: 20px;
  padding: 10px 20px;
  background: linear-gradient(45deg, red, yellow, blue);
  color: white;
  border: 3px solid purple;
  cursor: pointer;
}

.chaos-button:hover {
  transform: rotate(360deg);
  transition: transform 1s;
}

/* Styles délibérément chaotiques */
.chaos {
  background-color: #ff00ff;
  color: #00ff00;
  font-family: 'Comic Sans MS', 'Courier New', 'Papyrus', sans-serif;
  text-align: center;
}

button {
  background: linear-gradient(45deg, red, yellow, blue);
  color: white;
  font-size: 22px;
  font-weight: bold;
  padding: 20px;
  border: 5px dotted purple;
  cursor: crosshair;
}

input,
select {
  font-size: 24px;
  color: #ff0000;
  background-color: #0000ff;
  border: 3px dashed lime;
  padding: 5px;
}

h3 {
  font-size: 48px;
  color: #ff9900;
  text-transform: uppercase;
  letter-spacing: 5px;
}

label {
  font-size: 20px;
  color: #00ffff;
  font-style: italic;
}

img {
  border: 10px solid #00ff00;
  max-width: 50%;
}

button:hover {
  transform: rotate(360deg);
  transition: transform 1s;
  color: black;
}

.form-group {
  margin-bottom: 40px;
  border: 2px solid pink;
  padding: 10px;
  background-color: #ffccff;
  text-shadow: 2px 2px 4px #000000;
}

/* body {
  animation: background-chaos 2s infinite !important;
} */



/* @keyframes background-chaos {
  0% {
    background-color: #ff0000;
  }
  25% {
    background-color: #00ff00;
  }
  50% {
    background-color: #0000ff;
  }
  75% {
    background-color: #ffff00;
  }
  100% {
    background-color: #ff00ff;
  }
} */
</style>