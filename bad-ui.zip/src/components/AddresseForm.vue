<template>
  <div>
    <h3>Adresse</h3>
    <div class="form-group">
      <label for="country">Pays :</label>
      <div class="dropdown">
        <div class="dropdown-btn" @click="toggleDropdown">
          <img :src="selectedFlag" alt="Selected Flag">
          <span>Select a Country</span>
        </div>
        <div class="dropdown-content" v-if="isOpen">
          <div v-for="country in countries" :key="country.code" @click="selectCountry(country)">
            <img :src="country.flag" :alt="country.name" @error="handleImageError(country)">
          </div>
        </div>
      </div>
    </div>
    <div class="form-group">
      <label for="postalCode">Code postal :</label>
      <input
        type="text"
        id="postalCode"
        required
        :placeholder="postalCodePlaceholder"
        disabled
      />
      <button @click="incrementPostalCode">Incrémenter</button>
    </div>
    <div class="form-group">
      <label for="city">Ville :</label>
      <input
        type="text"
        id="city"
        v-model="form.city"
        @keydown="handleKeyDown"
        required
      />
    </div>
    <button @click="prevPage">Précédent</button>
    <button @click="nextPage">Suivant</button>
  </div>
</template>

<script>
export default {
  props: {
  },
  data() {
    return {
      countries: [
      { name: "Afghanistan", code: "af", flag: "https://flagcdn.com/w40/af.png" },
        { name: "Albania", code: "al", flag: "https://flagcdn.com/w40/al.png" },
        { name: "Algeria", code: "dz", flag: "https://flagcdn.com/w40/dz.png" },
        { name: "Andorra", code: "ad", flag: "https://flagcdn.com/w40/ad.png" },
        { name: "Angola", code: "ao", flag: "https://flagcdn.com/w40/ao.png" },
        { name: "Antigua and Barbuda", code: "ag", flag: "https://flagcdn.com/w40/ag.png" },
        { name: "Argentina", code: "ar", flag: "https://flagcdn.com/w40/ar.png" },
        { name: "Armenia", code: "am", flag: "https://flagcdn.com/w40/am.png" },
        { name: "Australia", code: "au", flag: "https://flagcdn.com/w40/au.png" },
        { name: "Austria", code: "at", flag: "https://flagcdn.com/w40/at.png" },
        { name: "Azerbaijan", code: "az", flag: "https://flagcdn.com/w40/az.png" },
        { name: "Bahamas", code: "bs", flag: "https://flagcdn.com/w40/bs.png" },
        { name: "Bahrain", code: "bh", flag: "https://flagcdn.com/w40/bh.png" },
        { name: "Bangladesh", code: "bd", flag: "https://flagcdn.com/w40/bd.png" },
        { name: "Barbados", code: "bb", flag: "https://flagcdn.com/w40/bb.png" },
        { name: "Belarus", code: "by", flag: "https://flagcdn.com/w40/by.png" },
        { name: "Belgium", code: "be", flag: "https://flagcdn.com/w40/be.png" },
        { name: "Belize", code: "bz", flag: "https://flagcdn.com/w40/bz.png" },
        { name: "Benin", code: "bj", flag: "https://flagcdn.com/w40/bj.png" },
        { name: "Bhutan", code: "bt", flag: "https://flagcdn.com/w40/bt.png" },
        { name: "Bolivia", code: "bo", flag: "https://flagcdn.com/w40/bo.png" },
        { name: "Bosnia and Herzegovina", code: "ba", flag: "https://flagcdn.com/w40/ba.png" },
        { name: "Botswana", code: "bw", flag: "https://flagcdn.com/w40/bw.png" },
        { name: "Brazil", code: "br", flag: "https://flagcdn.com/w40/br.png" },
        { name: "Brunei", code: "bn", flag: "https://flagcdn.com/w40/bn.png" },
        { name: "Bulgaria", code: "bg", flag: "https://flagcdn.com/w40/bg.png" },
        { name: "Burkina Faso", code: "bf", flag: "https://flagcdn.com/w40/bf.png" },
        { name: "Burundi", code: "bi", flag: "https://flagcdn.com/w40/bi.png" },
        { name: "Cabo Verde", code: "cv", flag: "https://flagcdn.com/w40/cv.png" },
        { name: "Cambodia", code: "kh", flag: "https://flagcdn.com/w40/kh.png" },
        { name: "Cameroon", code: "cm", flag: "https://flagcdn.com/w40/cm.png" },
        { name: "Canada", code: "ca", flag: "https://flagcdn.com/w40/ca.png" },
        { name: "Central African Republic", code: "cf", flag: "https://flagcdn.com/w40/cf.png" },
        { name: "Chad", code: "td", flag: "https://flagcdn.com/w40/td.png" },
        { name: "Chile", code: "cl", flag: "https://flagcdn.com/w40/cl.png" },
        { name: "China", code: "cn", flag: "https://flagcdn.com/w40/cn.png" },
        { name: "Colombia", code: "co", flag: "https://flagcdn.com/w40/co.png" },
        { name: "Comoros", code: "km", flag: "https://flagcdn.com/w40/km.png" },
        { name: "Congo", code: "cg", flag: "https://flagcdn.com/w40/cg.png" },
        { name: "Costa Rica", code: "cr", flag: "https://flagcdn.com/w40/cr.png" },
        { name: "Croatia", code: "hr", flag: "https://flagcdn.com/w40/hr.png" },
        { name: "Cuba", code: "cu", flag: "https://flagcdn.com/w40/cu.png" },
        { name: "Cyprus", code: "cy", flag: "https://flagcdn.com/w40/cy.png" },
        { name: "Czechia", code: "cz", flag: "https://flagcdn.com/w40/cz.png" },
        { name: "Denmark", code: "dk", flag: "https://flagcdn.com/w40/dk.png" },
        { name: "Djibouti", code: "dj", flag: "https://flagcdn.com/w40/dj.png" },
        { name: "Dominica", code: "dm", flag: "https://flagcdn.com/w40/dm.png" },
        { name: "Dominican Republic", code: "do", flag: "https://flagcdn.com/w40/do.png" },
        { name: "Ecuador", code: "ec", flag: "https://flagcdn.com/w40/ec.png" },
        { name: "Egypt", code: "eg", flag: "https://flagcdn.com/w40/eg.png" },
        { name: "El Salvador", code: "sv", flag: "https://flagcdn.com/w40/sv.png" },
        { name: "Equatorial Guinea", code: "gq", flag: "https://flagcdn.com/w40/gq.png" },
        { name: "Eritrea", code: "er", flag: "https://flagcdn.com/w40/er.png" },
        { name: "Estonia", code: "ee", flag: "https://flagcdn.com/w40/ee.png" },
        { name: "Eswatini", code: "sz", flag: "https://flagcdn.com/w40/sz.png" },
        { name: "Ethiopia", code: "et", flag: "https://flagcdn.com/w40/et.png" },
        { name: "Fiji", code: "fj", flag: "https://flagcdn.com/w40/fj.png" },
        { name: "Finland", code: "fi", flag: "https://flagcdn.com/w40/fi.png" },
        { name: "France", code: "fr", flag: "https://flagcdn.com/w40/fr.png" },
        { name: "Gabon", code: "ga", flag: "https://flagcdn.com/w40/ga.png" },
        { name: "Gambia", code: "gm", flag: "https://flagcdn.com/w40/gm.png" },
        { name: "Georgia", code: "ge", flag: "https://flagcdn.com/w40/ge.png" },
        { name: "Germany", code: "de", flag: "https://flagcdn.com/w40/de.png" },
        { name: "Ghana", code: "gh", flag: "https://flagcdn.com/w40/gh.png" },
        { name: "Greece", code: "gr", flag: "https://flagcdn.com/w40/gr.png" },
        { name: "Grenada", code: "gd", flag: "https://flagcdn.com/w40/gd.png" },
        { name: "Guatemala", code: "gt", flag: "https://flagcdn.com/w40/gt.png" },
        { name: "Guinea", code: "gn", flag: "https://flagcdn.com/w40/gn.png" },
        { name: "Guinea-Bissau", code: "gw", flag: "https://flagcdn.com/w40/gw.png" },
        { name: "Guyana", code: "gy", flag: "https://flagcdn.com/w40/gy.png" },
        { name: "Haiti", code: "ht", flag: "https://flagcdn.com/w40/ht.png" },
        { name: "Honduras", code: "hn", flag: "https://flagcdn.com/w40/hn.png" },
        { name: "Hungary", code: "hu", flag: "https://flagcdn.com/w40/hu.png" },
        { name: "Iceland", code: "is", flag: "https://flagcdn.com/w40/is.png" },
        { name: "India", code: "in", flag: "https://flagcdn.com/w40/in.png" },
        { name: "Indonesia", code: "id", flag: "https://flagcdn.com/w40/id.png" },
        { name: "Iran", code: "ir", flag: "https://flagcdn.com/w40/ir.png" },
        { name: "Iraq", code: "iq", flag: "https://flagcdn.com/w40/iq.png" },
        { name: "Ireland", code: "ie", flag: "https://flagcdn.com/w40/ie.png" },
        { name: "Israel", code: "il", flag: "https://flagcdn.com/w40/il.png" },
        { name: "Italy", code: "it", flag: "https://flagcdn.com/w40/it.png" },
        { name: "Jamaica", code: "jm", flag: "https://flagcdn.com/w40/jm.png" },
        { name: "Japan", code: "jp", flag: "https://flagcdn.com/w40/jp.png" },
        { name: "Jordan", code: "jo", flag: "https://flagcdn.com/w40/jo.png" },
        { name: "Kazakhstan", code: "kz", flag: "https://flagcdn.com/w40/kz.png" },
        { name: "Kenya", code: "ke", flag: "https://flagcdn.com/w40/ke.png" },
        { name: "Kiribati", code: "ki", flag: "https://flagcdn.com/w40/ki.png" },
        { name: "Kuwait", code: "kw", flag: "https://flagcdn.com/w40/kw.png" },
        { name: "Kyrgyzstan", code: "kg", flag: "https://flagcdn.com/w40/kg.png" },
        { name: "Laos", code: "la", flag: "https://flagcdn.com/w40/la.png" },
        { name: "Latvia", code: "lv", flag: "https://flagcdn.com/w40/lv.png" },
        { name: "Lebanon", code: "lb", flag: "https://flagcdn.com/w40/lb.png" },
        { name: "Lesotho", code: "ls", flag: "https://flagcdn.com/w40/ls.png" },
        { name: "Liberia", code: "lr", flag: "https://flagcdn.com/w40/lr.png" },
        { name: "Libya", code: "ly", flag: "https://flagcdn.com/w40/ly.png" },
        { name: "Liechtenstein", code: "li", flag: "https://flagcdn.com/w40/li.png" },
        { name: "Lithuania", code: "lt", flag: "https://flagcdn.com/w40/lt.png" },
        { name: "Luxembourg", code: "lu", flag: "https://flagcdn.com/w40/lu.png" },
        { name: "Madagascar", code: "mg", flag: "https://flagcdn.com/w40/mg.png" },
        { name: "Malawi", code: "mw", flag: "https://flagcdn.com/w40/mw.png" },
        { name: "Malaysia", code: "my", flag: "https://flagcdn.com/w40/my.png" },
        { name: "Maldives", code: "mv", flag: "https://flagcdn.com/w40/mv.png" },
        { name: "Mali", code: "ml", flag: "https://flagcdn.com/w40/ml.png" },
        { name: "Malta", code: "mt", flag: "https://flagcdn.com/w40/mt.png" },
        { name: "Marshall Islands", code: "mh", flag: "https://flagcdn.com/w40/mh.png" },
        { name: "Mauritania", code: "mr", flag: "https://flagcdn.com/w40/mr.png" },
        { name: "Mauritius", code: "mu", flag: "https://flagcdn.com/w40/mu.png" },
        { name: "Mexico", code: "mx", flag: "https://flagcdn.com/w40/mx.png" },
        { name: "Micronesia", code: "fm", flag: "https://flagcdn.com/w40/fm.png" },
        { name: "Moldova", code: "md", flag: "https://flagcdn.com/w40/md.png" },
        { name: "Monaco", code: "mc", flag: "https://flagcdn.com/w40/mc.png" },
        { name: "Mongolia", code: "mn", flag: "https://flagcdn.com/w40/mn.png" },
        { name: "Montenegro", code: "me", flag: "https://flagcdn.com/w40/me.png" },
        { name: "Morocco", code: "ma", flag: "https://flagcdn.com/w40/ma.png" },
        { name: "Mozambique", code: "mz", flag: "https://flagcdn.com/w40/mz.png" },
        { name: "Myanmar", code: "mm", flag: "https://flagcdn.com/w40/mm.png" },
        { name: "Namibia", code: "na", flag: "https://flagcdn.com/w40/na.png" },
        { name: "Nauru", code: "nr", flag: "https://flagcdn.com/w40/nr.png" },
        { name: "Nepal", code: "np", flag: "https://flagcdn.com/w40/np.png" },
        { name: "Netherlands", code: "nl", flag: "https://flagcdn.com/w40/nl.png" },
        { name: "New Zealand", code: "nz", flag: "https://flagcdn.com/w40/nz.png" },
        { name: "Nicaragua", code: "ni", flag: "https://flagcdn.com/w40/ni.png" },
        { name: "Niger", code: "ne", flag: "https://flagcdn.com/w40/ne.png" },
        { name: "Nigeria", code: "ng", flag: "https://flagcdn.com/w40/ng.png" },
        { name: "North Macedonia", code: "mk", flag: "https://flagcdn.com/w40/mk.png" },
        { name: "Norway", code: "no", flag: "https://flagcdn.com/w40/no.png" },
        { name: "Oman", code: "om", flag: "https://flagcdn.com/w40/om.png" },
        { name: "Pakistan", code: "pk", flag: "https://flagcdn.com/w40/pk.png" },
        { name: "Palau", code: "pw", flag: "https://flagcdn.com/w40/pw.png" },
        { name: "Palestine", code: "ps", flag: "https://flagcdn.com/w40/ps.png" },
        { name: "Panama", code: "pa", flag: "https://flagcdn.com/w40/pa.png" },
        { name: "Papua New Guinea", code: "pg", flag: "https://flagcdn.com/w40/pg.png" },
        { name: "Paraguay", code: "py", flag: "https://flagcdn.com/w40/py.png" },
        { name: "Peru", code: "pe", flag: "https://flagcdn.com/w40/pe.png" },
        { name: "Philippines", code: "ph", flag: "https://flagcdn.com/w40/ph.png" },
        { name: "Poland", code: "pl", flag: "https://flagcdn.com/w40/pl.png" },
        { name: "Portugal", code: "pt", flag: "https://flagcdn.com/w40/pt.png" },
        { name: "Qatar", code: "qa", flag: "https://flagcdn.com/w40/qa.png" },
        { name: "Romania", code: "ro", flag: "https://flagcdn.com/w40/ro.png" },
        { name: "Russia", code: "ru", flag: "https://flagcdn.com/w40/ru.png" },
        { name: "Rwanda", code: "rw", flag: "https://flagcdn.com/w40/rw.png" },
        { name: "Saint Kitts and Nevis", code: "kn", flag: "https://flagcdn.com/w40/kn.png" },
        { name: "Saint Lucia", code: "lc", flag: "https://flagcdn.com/w40/lc.png" },
        { name: "Saint Vincent and the Grenadines", code: "vc", flag: "https://flagcdn.com/w40/vc.png" },
        { name: "Samoa", code: "ws", flag: "https://flagcdn.com/w40/ws.png" },
        { name: "San Marino", code: "sm", flag: "https://flagcdn.com/w40/sm.png" },
        { name: "Sao Tome and Principe", code: "st", flag: "https://flagcdn.com/w40/st.png" },
        { name: "Saudi Arabia", code: "sa", flag: "https://flagcdn.com/w40/sa.png" },
        { name: "Senegal", code: "sn", flag: "https://flagcdn.com/w40/sn.png" },
        { name: "Serbia", code: "rs", flag: "https://flagcdn.com/w40/rs.png" },
        { name: "Seychelles", code: "sc", flag: "https://flagcdn.com/w40/sc.png" },
        { name: "Sierra Leone", code: "sl", flag: "https://flagcdn.com/w40/sl.png" },
        { name: "Singapore", code: "sg", flag: "https://flagcdn.com/w40/sg.png" },
        { name: "Slovakia", code: "sk", flag: "https://flagcdn.com/w40/sk.png" },
        { name: "Slovenia", code: "si", flag: "https://flagcdn.com/w40/si.png" },
        { name: "Solomon Islands", code: "sb", flag: "https://flagcdn.com/w40/sb.png" },
        { name: "Somalia", code: "so", flag: "https://flagcdn.com/w40/so.png" },
        { name: "South Africa", code: "za", flag: "https://flagcdn.com/w40/za.png" },
        { name: "South Korea", code: "kr", flag: "https://flagcdn.com/w40/kr.png" },
        { name: "South Sudan", code: "ss", flag: "https://flagcdn.com/w40/ss.png" },
        { name: "Spain", code: "es", flag: "https://flagcdn.com/w40/es.png" },
        { name: "Sri Lanka", code: "lk", flag: "https://flagcdn.com/w40/lk.png" },
        { name: "Sudan", code: "sd", flag: "https://flagcdn.com/w40/sd.png" },
        { name: "Suriname", code: "sr", flag: "https://flagcdn.com/w40/sr.png" },
        { name: "Sweden", code: "se", flag: "https://flagcdn.com/w40/se.png" },
        { name: "Switzerland", code: "ch", flag: "https://flagcdn.com/w40/ch.png" },
        { name: "Syria", code: "sy", flag: "https://flagcdn.com/w40/sy.png" },
        { name: "Tajikistan", code: "tj", flag: "https://flagcdn.com/w40/tj.png" },
        { name: "Tanzania", code: "tz", flag: "https://flagcdn.com/w40/tz.png" },
        { name: "Thailand", code: "th", flag: "https://flagcdn.com/w40/th.png" },
        { name: "Timor-Leste", code: "tl", flag: "https://flagcdn.com/w40/tl.png" },
        { name: "Togo", code: "tg", flag: "https://flagcdn.com/w40/tg.png" },
        { name: "Tonga", code: "to", flag: "https://flagcdn.com/w40/to.png" },
        { name: "Trinidad and Tobago", code: "tt", flag: "https://flagcdn.com/w40/tt.png" },
        { name: "Tunisia", code: "tn", flag: "https://flagcdn.com/w40/tn.png" },
        { name: "Turkey", code: "tr", flag: "https://flagcdn.com/w40/tr.png" },
        { name: "Turkmenistan", code: "tm", flag: "https://flagcdn.com/w40/tm.png" },
        { name: "Tuvalu", code: "tv", flag: "https://flagcdn.com/w40/tv.png" },
        { name: "Uganda", code: "ug", flag: "https://flagcdn.com/w40/ug.png" },
        { name: "Ukraine", code: "ua", flag: "https://flagcdn.com/w40/ua.png" },
        { name: "United Arab Emirates", code: "ae", flag: "https://flagcdn.com/w40/ae.png" },
        { name: "United Kingdom", code: "gb", flag: "https://flagcdn.com/w40/gb.png" },
        { name: "United States", code: "us", flag: "https://flagcdn.com/w40/us.png" },
        { name: "Uruguay", code: "uy", flag: "https://flagcdn.com/w40/uy.png" },
        { name: "Uzbekistan", code: "uz", flag: "https://flagcdn.com/w40/uz.png" },
        { name: "Vanuatu", code: "vu", flag: "https://flagcdn.com/w40/vu.png" },
        { name: "Vatican City", code: "va", flag: "https://flagcdn.com/w40/va.png" },
        { name: "Venezuela", code: "ve", flag: "https://flagcdn.com/w40/ve.png" },
        { name: "Vietnam", code: "vn", flag: "https://flagcdn.com/w40/vn.png" },
        { name: "Yemen", code: "ye", flag: "https://flagcdn.com/w40/ye.png" },
        { name: "Zambia", code: "zm", flag: "https://flagcdn.com/w40/zm.png" },
        { name: "Zimbabwe", code: "zw", flag: "https://flagcdn.com/w40/zw.png" }
      ],
      form: {
        city: "Veuillez renseigner le nom de votre ville dans le champ ci-dessous."
      },
      selectedFlag: 'https://flagcdn.com/w40/un.png',
      isOpen: false,
      isDeleting: false,
      postalCode: 0,
    };
  },
  computed: {
    postalCodePlaceholder() {
      return `Code postal : ${this.postalCode}`;
    },
  },
  mounted() {
    window.addEventListener('keydown', this.blockCtrlA);
    window.addEventListener('dblclick', this.blockDoubleClick);
  },
  beforeUnmount() {
    window.removeEventListener('keydown', this.blockCtrlA);
    window.removeEventListener('dblclick', this.blockDoubleClick);
  },
  methods: {
    blockCtrlA(event) {
      if ((event.ctrlKey || event.metaKey) && event.key === 'a') {
        event.preventDefault();
        alert("La sélection de tout le texte avec Ctrl+A est désactivée !");
      }
    },
    blockDoubleClick(event) {
      event.preventDefault();
      alert("Le double-clic pour sélectionner du texte est désactivé !");
    },
    handleKeyDown(event) {
      if ((event.key === "Backspace" || event.key === "Delete") && this.isDeleting) {
        event.preventDefault();
      } else if (event.key === "Backspace" || event.key === "Delete") {
        this.isDeleting = true;
        setTimeout(() => {
          this.isDeleting = false;
        }, 500);
      }
    },
    toggleDropdown() {
      this.isOpen = !this.isOpen;
    },
    selectCountry(country) {
      this.selectedFlag = country.flag;
      this.form.country = country.name;
      this.isOpen = false;
    },
    handleImageError(country) {
      country.flag = 'https://via.placeholder.com/40x30?text=?';
    },
    incrementPostalCode() {
      this.postalCode++;
    },
    nextPage() {
      this.$emit('next', this.form);
    },
    prevPage() {
      this.$emit('prev');
    },
  },
};
</script>


<style scoped>
 css
/* Styles généraux */
body {
  font-family: Arial, sans-serif;
  background-color: #f4f4f4;
  margin: 0;
  padding: 0;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

input[type="text"],
input[type="file"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type="text"]:disabled {
  background-color: #e9e9e9;
  cursor: not-allowed;
}

button {
  padding: 10px 20px;
  margin-top: 10px;
  border: none;
  border-radius: 4px;
  background-color: #007bff;
  color: white;
  cursor: pointer;
  font-size: 16px;
}

button:hover {
  background-color: #0056b3;
}

/* Styles pour le dropdown */
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-btn {
  display: flex;
  align-items: center;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  cursor: pointer;
  background-color: white;
}

.dropdown-btn img {
  margin-right: 10px;
}

.dropdown-content {
  position: absolute;
  background-color: white;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  max-height: 200px;
  overflow-y: auto;
}

.dropdown-content div {
  padding: 10px;
  cursor: pointer;
}

.dropdown-content div:hover {
  background-color: #f1f1f1;
}

.dropdown-content img {
  margin-right: 10px;
}

/* Styles pour les boutons de navigation */
.nav-buttons {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}

.nav-buttons button {
  width: 48%;
}

</style>