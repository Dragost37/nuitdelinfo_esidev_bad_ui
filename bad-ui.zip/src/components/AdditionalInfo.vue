<template>
  <div>
    <h3>Informations personnelles</h3>

    <!-- Menu déroulant pour la nationalité -->
    <div class="form-group">
      <label for="nationality">Nationalité :</label>
      <div
        class="custom-select"
        tabindex="0"
        @keydown.prevent="blockKeyboardNavigation"
        @click="toggleDropdown"
      >
        <div class="selected-option">
          {{ selectedCountry || "Sélectionnez une nationalité" }}
        </div>
        <ul v-if="dropdownOpen" class="dropdown-options">
          <li
            v-for="country in shuffledCountries"
            :key="country"
            @click="selectCountry(country)"
          >
            {{ country }}
          </li>
        </ul>
      </div>
    </div>

    <!-- Curseur pour la date de naissance -->
    <div class="form-group">
      <label for="birthDate">Date de naissance :</label>
      <div class="birth-date-slider">
        <input
          type="range"
          id="birthDate"
          :min="0"
          :max="109574"
          v-model="birthDateValue"
          @input="updateBirthDate"
        />
        <div class="slider-value">
          Date sélectionnée : {{ formattedDate }}
        </div>
      </div>
    </div>
  <div class="form-group">
      <label for="gender">Genre :</label>
      <div
        class="custom-select"
        tabindex="0"
        @keydown.prevent="blockKeyboardNavigation"
        @click="toggleGenderDropdown"
      >
        <div class="selected-option">
          {{ selectedGender || "Sélectionnez un genre" }}
        </div>
        <ul v-if="genderDropdownOpen" class="dropdown-options">
          <li
            v-for="gender in shuffledGenders"
            :key="gender"
            @click="selectGender(gender)"
          >
            {{ gender }}
          </li>
        </ul>
      </div>
    </div>
    <!-- Boutons de navigation -->
    <div>
      <button @click="prevPage">Précédent</button>
      <button @click="nextPage">Suivant</button>
    </div>
  </div>
</template>

<script>
// import "../assets/InfoAdd.css";

export default {
  data() {
    return {
      countries: [
      "Afghanistan", "Albanie", "Algérie", "Andorre", "Angola", "Antigua-et-Barbuda", 
  "Arabie saoudite", "Argentine", "Arménie", "Australie", "Autriche", "Azerbaïdjan", 
  "Bahamas", "Bahreïn", "Bangladesh", "Barbade", "Belgique", "Belize", "Bénin", "Bhoutan", 
  "Biélorussie", "Birmanie", "Bolivie", "Bosnie-Herzégovine", "Botswana", "Brésil", 
  "Brunei", "Bulgarie", "Burkina Faso", "Burundi", "Cambodge", "Cameroun", "Canada", 
  "Cap-Vert", "République centrafricaine", "Chili", "Chine", "Chypre", "Colombie", 
  "Comores", "République du Congo", "République démocratique du Congo", "Corée du Nord", 
  "Corée du Sud", "Costa Rica", "Côte d’Ivoire", "Croatie", "Cuba", "Danemark", 
  "Djibouti", "Dominique", "Égypte", "Émirats arabes unis", "Équateur", "Érythrée", 
  "Espagne", "Eswatini", "Estonie", "États-Unis", "Éthiopie", "Fidji", "Finlande", 
  "France", "Gabon", "Gambie", "Géorgie", "Ghana", "Grèce", "Grenade", "Guatemala", 
  "Guinée", "Guinée-Bissau", "Guinée équatoriale", "Guyana", "Haïti", "Honduras", 
  "Hongrie", "Îles Cook", "Îles Marshall", "Inde", "Indonésie", "Irak", "Iran", 
  "Irlande", "Islande", "Israël", "Italie", "Jamaïque", "Japon", "Jordanie", "Kazakhstan", 
  "Kenya", "Kirghizistan", "Kiribati", "Koweït", "Laos", "Lesotho", "Lettonie", "Liban", 
  "Libéria", "Libye", "Liechtenstein", "Lituanie", "Luxembourg", "Macédoine du Nord", 
  "Madagascar", "Malaisie", "Malawi", "Maldives", "Mali", "Malte", "Maroc", "Maurice", 
  "Mauritanie", "Mexique", "Micronésie", "Moldavie", "Monaco", "Mongolie", "Monténégro", 
  "Mozambique", "Namibie", "Nauru", "Népal", "Nicaragua", "Niger", "Nigéria", "Norvège", 
  "Nouvelle-Zélande", "Oman", "Ouganda", "Ouzbékistan", "Pakistan", "Palaos", "Palestine", 
  "Panama", "Papouasie-Nouvelle-Guinée", "Paraguay", "Pays-Bas", "Pérou", "Philippines", 
  "Pologne", "Portugal", "Qatar", "Roumanie", "Royaume-Uni", "Russie", "Rwanda", 
  "Saint-Christophe-et-Niévès", "Saint-Marin", "Saint-Vincent-et-les-Grenadines", 
  "Sainte-Lucie", "Salomon", "Salvador", "Samoa", "Sao Tomé-et-Principe", "Sénégal", 
  "Serbie", "Seychelles", "Sierra Leone", "Singapour", "Slovaquie", "Slovénie", "Somalie", 
  "Soudan", "Soudan du Sud", "Sri Lanka", "Suède", "Suisse", "Suriname", "Syrie", 
  "Tadjikistan", "Tanzanie", "Tchad", "République tchèque", "Thaïlande", "Timor oriental", 
  "Togo", "Tonga", "Trinité-et-Tobago", "Tunisie", "Turkménistan", "Turquie", "Tuvalu", 
  "Ukraine", "Uruguay", "Vanuatu", "Vatican", "Venezuela", "Viêt Nam", "Yémen", 
  "Zambie", "Zimbabwe"
      ],
      selectedCountry: "",
      dropdownOpen: false,

      // Données pour les genres
      genders: [
      "Homme",
      "Femme",
      "Agender",
      "Androgyne",
      "Bigender",
      "Cis",
      "Cisgenre Femme",
      "Cisgenre Homme",
      "Cisgenre",
      "Femme Transgenre",
      "Homme Transgenre",
      "Personne Transgenre",
      "Non-binaire",
      "Genre Fluide",
      "Genre Non-conforme",
      "Genre Variant",
      "Agenre",
      "Pangender",
      "Genderqueer",
      "Intersexe",
      "Neutrois",
      "Sans Genre",
      "Deux-esprits",
      "Demi-femme",
      "Demi-homme",
      "Transféminin",
      "Transmasculin",
      "Femme Cisgenre",
      "Homme Cisgenre",
      "Femme Transsexuelle",
      "Homme Transsexuel",
      "Personne Transsexuelle",
      "Femme à Homme (FTM)",
      "Homme à Femme (MTF)",
      "Questionnement",
      "Androgyne",
      "Autre",
      "Non étiqueté",
      "Genderfluid",
      "Personne Multigenre",
      "Personne Xénique",
      "Indéfini",
      "Troisième Genre",
      "Quatrième Genre",
      "Identité de Genre Inclusive",
      "Identité de Genre Expansive"
      ],
      selectedGender: "",
      genderDropdownOpen: false,
            // Propriétés pour la date de naissance
      birthDateValue: 54787, // Valeur initiale (milieu de la plage, correspondant à 150 ans après 1900)
      startDate: new Date("1900-01-01").getTime(), // Date de début pour le calcul
    };
  },
  computed: {
    shuffledCountries() {
      return this.countries
        .map((value) => ({ value, sort: Math.random() }))
        .sort((a, b) => a.sort - b.sort)
        .map(({ value }) => value);
    },
    formattedDate() {
      const daysFromStart = this.birthDateValue;
      const date = new Date(this.startDate + daysFromStart * 24 * 60 * 60 * 1000);
      const day = String(date.getDate()).padStart(2, "0");
      const month = String(date.getMonth() + 1).padStart(2, "0");
      const year = date.getFullYear();
      return `${day}/${month}/${year}`;
    },
        shuffledGenders() {
      return this.genders
        .map((value) => ({ value, sort: Math.random() }))
        .sort((a, b) => a.sort - b.sort)
        .map(({ value }) => value);
    },
  },
  methods: {
    toggleDropdown() {
      this.dropdownOpen = !this.dropdownOpen;
    },
    selectCountry(country) {
      this.selectedCountry = country;
      this.dropdownOpen = false;
    },
        // Menu déroulant pour le genre
    toggleGenderDropdown() {
      this.genderDropdownOpen = !this.genderDropdownOpen;
    },
    selectGender(gender) {
      this.selectedGender = gender;
      this.genderDropdownOpen = false;
    },
    blockKeyboardNavigation(event) {
      event.preventDefault();
    },
    updateBirthDate() {
      console.log("Date mise à jour :", this.formattedDate);
    },
    nextPage() {
      this.$emit("next");
    },
    prevPage() {
      this.$emit("prev");
    },
  },
};
</script>


}

<style scoped>
/* Styles de base */

/* Menu déroulant */
.custom-select {
  position: relative;
  width: 320px;
  padding: 12px 15px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  font-size: 16px;
  transition: all 0.3s ease;
}

.custom-select:hover {
  border-color: #5a5a5a;
  box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.15);
}

.selected-option {
  font-size: 16px;
  color: #333;
}

.dropdown-options {
  list-style-type: none;
  padding: 0;
  margin: 5px 0 0;
  border: 1px solid #ddd;
  background: #fff;
  position: absolute;
  width: 100%;
  z-index: 10;
  max-height: 200px;
  overflow-y: auto;
  border-radius: 8px;
  box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.1);
}

.dropdown-options::-webkit-scrollbar {
  width: 6px;
}

.dropdown-options::-webkit-scrollbar-thumb {
  background-color: #ccc;
  border-radius: 4px;
}

.dropdown-options li {
  padding: 12px 15px;
  cursor: pointer;
  transition: background-color 0.2s ease, color 0.2s ease;
}

.dropdown-options li:hover {
  background-color: #f5f5f5;
  color: #007bff;
}

/* Curseur pour la date de naissance */
.birth-date-slider {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 30px;
  width: 100%;
}

input[type="range"] {
  width: 100%;
  margin: 20px 0;
  background: linear-gradient(to right, #007bff, #007bff 50%, #e9ecef 50%);
  height: 6px;
  border-radius: 3px;
  -webkit-appearance: none;
  appearance: none;
  transition: background 0.3s ease;
}

input[type="range"]:hover {
  background: linear-gradient(to right, #0056b3, #0056b3 50%, #e9ecef 50%);
}

input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 20px;
  height: 20px;
  background: #007bff;
  border: 2px solid #fff;
  border-radius: 50%;
  box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.2s ease, background-color 0.2s ease;
}

input[type="range"]::-webkit-slider-thumb:hover {
  transform: scale(1.2);
  background-color: #0056b3;
}

input[type="range"]::-moz-range-thumb {
  width: 20px;
  height: 20px;
  background: #007bff;
  border: 2px solid #fff;
  border-radius: 50%;
  box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
  cursor: pointer;
}

.slider-value {
  font-size: 16px;
  font-weight: 500;
  color: #333;
  margin-top: 10px;
}

/* Labels */
label {
  font-size: 14px;
  color: #555;
  font-weight: bold;
  margin-bottom: 8px;
  display: block;
}

/* Boutons */
button {
  padding: 12px 20px;
  font-size: 16px;
  font-weight: 600;
  border: none;
  border-radius: 8px;
  background: #007bff;
  color: #fff;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.2s ease;
}

button:hover {
  background-color: #0056b3;
  transform: scale(1.05);
}

button:active {
  transform: scale(1);
}
</style>